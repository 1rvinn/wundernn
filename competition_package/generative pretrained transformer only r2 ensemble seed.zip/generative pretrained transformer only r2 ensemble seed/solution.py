"""
solution.py

5-fold ensemble inference for the Ordered 5-Fold LSTM+Attention model.

This script:
  ✓ Loads 5 checkpoints:  <base>.fold0.pt ... <base>.fold4.pt
  ✓ Reconstructs the model architecture exactly (separate heads / no heads)
  ✓ Maintains a state buffer per sequence
  ✓ For every prediction:
        runs all 5 models → averages predictions → returns result
"""

import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
import os

# ============ COMPETITION IMPORT ============
try:
    from utils import DataPoint
except ImportError:
    print("Local mode: using dummy DataPoint")
    from dataclasses import dataclass
    @dataclass
    class DataPoint:
        seq_ix: int
        step_in_seq: int
        need_prediction: bool
        state: np.ndarray


# =====================================================================
# MODEL — SAME ARCHITECTURE AS TRAINING
# =====================================================================
class LSTMAttentionModel(nn.Module):
    def __init__(self, input_size, hidden_size=128, num_layers=2, dropout=0.1,
                 separate_heads=False, easy_idx=None, hard_idx=None):
        super().__init__()

        self.hidden_size = hidden_size
        self.input_size = input_size
        self.separate_heads = separate_heads
        self.easy_idx = easy_idx
        self.hard_idx = hard_idx

        # Input projection
        self.input_projection = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.GELU()
        )

        # Bidirectional LSTM
        self.lstm = nn.LSTM(
            input_size=hidden_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout,
            bidirectional=True
        )

        # Attention layer
        self.attention_fc = nn.Linear(hidden_size * 2, 1)

        # Decoders
        if not separate_heads:
            self.fc = nn.Linear(hidden_size * 2, input_size)
        else:
            self.fc_easy = nn.Linear(hidden_size * 2, len(easy_idx)) if len(easy_idx) > 0 else None
            self.fc_hard = nn.Linear(hidden_size * 2, len(hard_idx)) if len(hard_idx) > 0 else None

    def forward(self, x):
        x_proj = self.input_projection(x)
        lstm_out, _ = self.lstm(x_proj)

        att_logits = self.attention_fc(lstm_out)
        att_w = F.softmax(att_logits, dim=1)

        ctx = torch.sum(att_w * lstm_out, dim=1)

        # Single-head mode
        if not self.separate_heads:
            return self.fc(ctx)

        # Two-head mode (easy/hard)
        batch = ctx.size(0)
        device = ctx.device
        out = torch.zeros((batch, self.input_size), device=device)

        if self.fc_easy is not None:
            out[:, self.easy_idx] = self.fc_easy(ctx)
        if self.fc_hard is not None:
            out[:, self.hard_idx] = self.fc_hard(ctx)

        return out


# =====================================================================
# INFERENCE MODEL — loads 5 folds and ensembles predictions
# =====================================================================
class PredictionModel:
    def __init__(self):
        print("Initializing 5-fold ensemble PredictionModel...")

        self.seq_len = 100
        script_dir = os.path.dirname(os.path.abspath(__file__))
        base_name = "lstm_attention_proj_checkpoint_weighted_"   # <checkpoint>.foldN.pt
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Will hold 5 models
        self.models = []
        self.num_folds = 5

        # Buffers per active sequence
        self.current_seq_ix = -1
        self.state_buffer = []

        # ----------------------
        # LOAD ALL 5 FOLD MODELS
        # ----------------------
        for fold in range(self.num_folds):
            ckpt_path = os.path.join(script_dir, f"{base_name}.fold{fold}.pt")
            print(f"Loading: {ckpt_path}")

            ckpt = torch.load(ckpt_path, map_location=self.device)
            args = ckpt["args"]
            state = ckpt["model_state_dict"]
            feature_weights = ckpt["feature_weights"]

            input_size = len(feature_weights)
            separate_heads = args.get("separate_heads", False)

            # reconstruct easy/hard indices if needed
            if separate_heads:
                median = np.median(feature_weights)
                hard_idx = [i for i,w in enumerate(feature_weights) if w > median]
                easy_idx = [i for i,w in enumerate(feature_weights) if w <= median]
            else:
                easy_idx = hard_idx = None

            model = LSTMAttentionModel(
                input_size=input_size,
                hidden_size=args["hidden_size"],
                num_layers=args["num_layers"],
                dropout=args["dropout"],
                separate_heads=separate_heads,
                easy_idx=easy_idx,
                hard_idx=hard_idx
            )

            model.load_state_dict(state)
            model.to(self.device)
            model.eval()
            self.models.append(model)

        print("All 5 models loaded.\n")

    # ------------------------------------------------------------------
    # PREDICT (ensemble)
    # ------------------------------------------------------------------
    def predict(self, data_point: DataPoint):
        # Reset buffer when a new sequence starts
        if data_point.seq_ix != self.current_seq_ix:
            self.current_seq_ix = data_point.seq_ix
            self.state_buffer = []

        # Append state
        self.state_buffer.append(data_point.state.astype(np.float32))
        if len(self.state_buffer) > self.seq_len:
            self.state_buffer.pop(0)

        # Only predict if required
        if not data_point.need_prediction:
            return None

        # Build window (pad if shorter than 100)
        window = np.array(self.state_buffer, dtype=np.float32)
        if len(window) < self.seq_len:
            pad_len = self.seq_len - len(window)
            pad = np.zeros((pad_len, window.shape[1]), dtype=np.float32)
            window = np.vstack([pad, window])

        x = torch.from_numpy(window).unsqueeze(0).float().to(self.device)

        # Ensemble prediction = average of all folds
        preds = []
        with torch.no_grad():
            for model in self.models:
                preds.append(model(x).cpu().numpy()[0])  # (D,)

        final_pred = np.mean(preds, axis=0)

        return final_pred
