import os
import sys
import numpy as np


CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
# Add project root folder to path for importing utils
sys.path.append(f"{CURRENT_DIR}/..")

from utils import DataPoint, ScorerStepByStep


# This list should be populated with the best alpha for each feature
# from the optimization script. You need to ensure the length of this list
# matches the number of features in the dataset.

class PredictionModel:
    """
    Simple model that predicts the next value as an exponential moving average
    of all previous values in the current sequence, with a separate alpha for each feature.
    """

    def __init__(self):
        self.current_seq_ix = None
        self.ema = None
        # Convert to numpy array for vectorized operations\
        best_alphas = [0.08, 0.05, 0.11, 0.05, 0.03, 0.07, 0.03, 0.08, 0.04, 0.03, 0.04, 0.06, 0.04, 0.08, 0.11, 0.04, 0.05, 0.05, 0.08, 0.09, 0.11, 0.03, 0.05, 0.06, 0.05, 0.05, 0.08, 0.05, 0.07, 0.02, 0.05, 0.09] 
        self.alphas = np.array(best_alphas)

    def predict(self, data_point: DataPoint) -> np.ndarray:
        if self.current_seq_ix != data_point.seq_ix:
            self.current_seq_ix = data_point.seq_ix
            self.ema = None

        current_state = data_point.state.copy()
        if self.ema is None:
            self.ema = current_state
        else:
            # Perform element-wise EMA calculation
            self.ema = self.alphas * current_state + (1 - self.alphas) * self.ema

        if not data_point.need_prediction:
            return None

        return self.ema.copy()


if __name__ == "__main__":
    # Check existence of test file
    test_file = f"{CURRENT_DIR}/../datasets/train.parquet"

    # Create and test our model, passing the list of alphas
    model = PredictionModel()

    # Load data into scorer
    scorer = ScorerStepByStep(test_file)

    print("Testing model with exponential moving average...")
    print(f"Feature dimensionality: {scorer.dim}")
    print(f"Number of rows in dataset: {len(scorer.dataset)}")

    # Evaluate our solution
    results = scorer.score(model)

    print("\nResults:")
    print(f"Mean R² across all features: {results['mean_r2']:.6f}")
    print("\nR² for first 5 features:")
    for i in range(min(5, len(scorer.features))):
        feature = scorer.features[i]
        print(f"  {feature}: {results[feature]:.6f}")

    print(f"\nTotal features: {len(scorer.features)}")

    print("\n" + "=" * 60)
    print("Try submitting an archive with solution.py file")
    print("to test the solution submission mechanism!")
    print("=" * 60)
