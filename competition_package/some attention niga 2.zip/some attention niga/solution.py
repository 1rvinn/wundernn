"""
Solution file for the 5-Fold Ensemble LSTMAttentionModel.

Strategy:
1. Loads 5 separate model checkpoints (folds 0-4).
2. Uses the Additive Attention (Bahdanau) + Input Projection architecture.
3. Feeds RAW unscaled data to the models.
4. Averages the predictions from all 5 models (Bagging Ensemble).
"""

import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
import os

# --- 1. DATA STRUCTURES ---
# Required by competition environment
try:
    from utils import DataPoint
except ImportError:
    from dataclasses import dataclass
    @dataclass
    class DataPoint:
        seq_ix: int
        step_in_seq: int
        need_prediction: bool
        state: np.ndarray

# --- 2. MODEL DEFINITION ---
# Must match the training script EXACTLY to load weights correctly.
class LSTMAttentionModel(nn.Module):
    """
    LSTM encoder (bidirectional) + Bahdanau-style additive attention.
    """
    def __init__(self, input_size, hidden_size=128, num_layers=2, dropout=0.1, attn_dropout=0.1):
        super().__init__()
        self.hidden_size = hidden_size
        self.bidirectional = True
        self.num_directions = 2 if self.bidirectional else 1

        # Input projection
        self.input_projection = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.GELU()
        )

        # Encoder LSTM
        self.lstm = nn.LSTM(
            input_size=hidden_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
            bidirectional=self.bidirectional
        )

        enc_dim = hidden_size * self.num_directions

        # Additive attention parameters
        self.W_h = nn.Linear(enc_dim, enc_dim, bias=False)
        self.W_s = nn.Linear(enc_dim, enc_dim, bias=False)
        self.v = nn.Linear(enc_dim, 1, bias=False)

        self.attn_dropout = nn.Dropout(attn_dropout)

        # Fusion layer
        self.fusion = nn.Sequential(
            nn.Linear(enc_dim * 2, enc_dim),
            nn.LayerNorm(enc_dim),
            nn.GELU()
        )

        # Final decoder
        self.fc = nn.Linear(enc_dim, input_size)

    def forward(self, x):
        # x: (batch, seq_len, input_size)
        
        # Project
        x_proj = self.input_projection(x)

        # LSTM
        lstm_out, (h_n, c_n) = self.lstm(x_proj)

        # Build query/state 's'
        if self.bidirectional:
            forward_h = h_n[-2]
            backward_h = h_n[-1]
            s = torch.cat([forward_h, backward_h], dim=1)
        else:
            s = h_n[-1]

        # Attention Scores
        Wh = self.W_h(lstm_out)
        Ws = self.W_s(s).unsqueeze(1)
        energy = torch.tanh(Wh + Ws)
        logits = self.v(energy).squeeze(-1)

        attn_weights = torch.softmax(logits, dim=1)
        # attn_weights = self.attn_dropout(attn_weights) # Dropout disabled in inference usually, but doesn't matter for eval()

        # Context Vector
        context_vector = torch.sum(attn_weights.unsqueeze(-1) * lstm_out, dim=1)

        # Fusion
        combined = torch.cat([context_vector, s], dim=1)
        fused = self.fusion(combined)

        # Decode
        out = self.fc(fused)
        return out

# --- 3. PREDICTION ENGINE ---

class PredictionModel:
    def __init__(self):
        print("Initializing PredictionModel (5-Fold Ensemble)...")
        
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Hyperparameters (Must match training Args)
        self.seq_len = 150
        self.hidden_size = 64
        self.num_layers = 2
        self.dropout = 0.0
        self.n_folds = 5
        
        # Path configuration
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.checkpoint_prefix = 'lstm_attention_raw_checkpoint_fold_fold'
        
        self.models = []
        self.input_size = None # Will be inferred
        
        # Load all 5 models
        self._load_ensemble()
        
        # Inference Buffer
        self.current_seq_ix = -1
        self.state_buffer = []
        
    def _load_ensemble(self):
        """Loads models for fold 0 through 4."""
        for i in range(self.n_folds):
            # Filename format: lstm_attention_raw_checkpoint_fold_0.pt
            # Note: Training script uses f"{prefix}_{fold_idx}.pt", check the underscore carefully.
            # Based on your script: f"{args.checkpoint_prefix}_fold_{fold_idx}.pt" -> fold_0.pt
            
            filename = f"{self.checkpoint_prefix}_{i}.pt" 
            path = os.path.join(self.script_dir, filename)
            
            if not os.path.exists(path):
                print(f"Warning: Checkpoint {filename} not found. Skipping.")
                continue
                
            try:
                state_dict = torch.load(path, map_location=self.device)
                
                # Infer Input Size from the first layer weight shape if not set
                if self.input_size is None:
                    # input_projection.0.weight shape is (hidden_size, input_size)
                    weight_shape = state_dict['input_projection.0.weight'].shape
                    self.input_size = weight_shape[1]
                    print(f"Inferred input size: {self.input_size}")
                
                model = LSTMAttentionModel(
                    input_size=self.input_size,
                    hidden_size=self.hidden_size,
                    num_layers=self.num_layers,
                    dropout=self.dropout
                )
                model.load_state_dict(state_dict)
                model.to(self.device).eval()
                self.models.append(model)
                
            except Exception as e:
                print(f"Error loading {filename}: {e}")
                
        if not self.models:
            raise RuntimeError("No models loaded! Check checkpoint filenames.")
        print(f"Successfully loaded {len(self.models)} models.")

    def predict(self, data_point: DataPoint) -> np.ndarray | None:
        # 1. Manage Sliding Window Buffer
        if data_point.seq_ix != self.current_seq_ix:
            self.current_seq_ix = data_point.seq_ix
            self.state_buffer = []

        self.state_buffer.append(data_point.state.astype(np.float32))

        # Keep buffer at max seq_len
        if len(self.state_buffer) > self.seq_len:
            self.state_buffer.pop(0)

        if not data_point.need_prediction:
            return None

        # 2. Prepare Input Tensor
        window = np.array(self.state_buffer, dtype=np.float32)
        
        # Pad if short
        if len(window) < self.seq_len:
            pad_len = self.seq_len - len(window)
            pad = np.zeros((pad_len, self.input_size), dtype=np.float32)
            window = np.vstack([pad, window])
            
        # (1, seq_len, input_size)
        x = torch.from_numpy(window).float().unsqueeze(0).to(self.device)

        # 3. Ensemble Inference
        preds = []
        with torch.no_grad():
            for model in self.models:
                # Output is (1, input_size)
                out = model(x)
                preds.append(out.cpu().numpy())
        
        # 4. Average Predictions
        # Stack -> (5, 1, 32) -> Mean -> (1, 32)
        avg_pred = np.mean(np.array(preds), axis=0)
        
        return avg_pred.squeeze(0)

if __name__ == "__main__":
    # Check existence of test file
    test_file = f"{os.path.dirname(os.path.abspath(__file__))}/../datasets/train.parquet"

    # Create and test our model
    model = PredictionModel()

    # Load data into scorer
    from utils import ScorerStepByStep
    scorer = ScorerStepByStep(test_file)

    print("Testing simple model with moving average...")
    print(f"Feature dimensionality: {scorer.dim}")
    print(f"Number of rows in dataset: {len(scorer.dataset)}")

    # Evaluate our solution
    results = scorer.score(model)

    print("\nResults:")
    print(f"Mean R² across all features: {results['mean_r2']:.6f}")
    print("\nR² for first 5 features:")
    for i in range(min(5, len(scorer.features))):
        feature = scorer.features[i]
        print(f"  {feature}: {results[feature]:.6f}")

    print(f"\nTotal features: {len(scorer.features)}")

    print("\n" + "=" * 60)
    print("Try submitting an archive with solution.py file")
    print("to test the solution submission mechanism!")
    print("=" * 60)

