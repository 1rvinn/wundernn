"""
Solution file for the 2-Model Ensemble.

Models included:
1. 'LSTMModel': Simple Stateful LSTM (Trained on Top 90%).
2. 'LSTMAttentionModel': Attention + Input Projection (Trained on Fold 4).

This script:
- Defines both distinct model architectures.
- Loads specific checkpoints:
    - 'lstm_stateful_raw_stable_checkpoint.pt'
    - 'lstm_attention_raw_checkpoint_fold_fold_4.pt'
- Runs inference on both and averages the result (0.5 * A + 0.5 * B).
"""

import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
import os

# DataPoint stub for local testing
try:
    from utils import DataPoint
except ImportError:
    from dataclasses import dataclass
    @dataclass
    class DataPoint:
        seq_ix: int
        step_in_seq: int
        need_prediction: bool
        state: np.ndarray

# ==============================================================================
# MODEL A: Simple Stateful LSTM (Matches train_lstm_stateful.py)
# ==============================================================================
class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size=128, num_layers=2, dropout=0.1):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=input_size, 
            hidden_size=hidden_size, 
            num_layers=num_layers, 
            batch_first=True,
            dropout=dropout
        )
        self.fc = nn.Linear(hidden_size, input_size)

    def forward(self, x):
        out, _ = self.lstm(x) 
        predictions = self.fc(out)
        return predictions

# ==============================================================================
# MODEL B: Attention + Input Projection (Matches train_kfold.py)
# ==============================================================================
class LSTMAttentionModel(nn.Module):
    def __init__(self, input_size, hidden_size=128, num_layers=2, dropout=0.1):
        super().__init__()
        self.hidden_size = hidden_size
        
        # --- Improvement C: Input Projection ---
        self.input_projection = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.GELU() 
        )
        
        # Encoder (Input size is hidden_size due to projection)
        self.lstm = nn.LSTM(input_size=hidden_size, 
                            hidden_size=hidden_size, 
                            num_layers=num_layers, 
                            batch_first=True, 
                            dropout=dropout,
                            bidirectional=True)
        
        # Attention
        self.attention_fc = nn.Linear(hidden_size * 2, 1)
        
        # Decoder
        self.fc = nn.Linear(hidden_size * 2, input_size)

    def forward(self, x):
        # 1. Apply Input Projection
        x_proj = self.input_projection(x)
        
        # 2. LSTM
        lstm_out, (h_n, c_n) = self.lstm(x_proj)
        
        # 3. Attention
        attention_logits = self.attention_fc(lstm_out)
        attention_weights = F.softmax(attention_logits, dim=1)
        context_vector = torch.sum(attention_weights * lstm_out, dim=1)
        
        # 4. Decode
        return self.fc(context_vector)

# ==============================================================================
# PREDICTION CLASS
# ==============================================================================
class PredictionModel:
    def __init__(self):
        print("Initializing 2-Model Ensemble (Stateful + Fold 4)...")
        script_dir = os.path.dirname(os.path.abspath(__file__))
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        
        # --- Shared Config ---
        self.seq_len = 100
        
        # --- Load Model A (Stateful) ---
        self.model_a = None
        path_a = os.path.join(script_dir, 'lstm_stateful_raw_stable_checkpoint.pt')
        try:
            state_dict_a = torch.load(path_a, map_location=self.device)
            
            # Infer input size A (from LSTM weights)
            input_size_a = state_dict_a['lstm.weight_ih_l0'].shape[1]
            
            # Note: Hardcoded hidden/layers based on your script defaults. 
            # Ideally, these are saved in a config, but we match the script provided.
            self.model_a = LSTMModel(
                input_size=input_size_a, 
                hidden_size=128, 
                num_layers=2, 
                dropout=0.0 # No dropout at inference
            )
            self.model_a.load_state_dict(state_dict_a)
            self.model_a.to(self.device).eval()
            print(f"Loaded Model A (Stateful) | Input Size: {input_size_a}")
        except Exception as e:
            print(f"CRITICAL: Failed to load Model A at {path_a}: {e}")
            raise e

        # --- Load Model B (Attention Fold 4) ---
        self.model_b = None
        # Based on your training script logic: f"{prefix}_fold_{idx}.pt"
        # prefix = 'lstm_attention_raw_checkpoint_fold'
        path_b = os.path.join(script_dir, 'lstm_attention_raw_checkpoint_fold_fold.pt')
        
        try:
            state_dict_b = torch.load(path_b, map_location=self.device)
            
            # Infer input size B (from Input Projection weights)
            input_size_b = state_dict_b['input_projection.0.weight'].shape[1]
            hidden_size_b = state_dict_b['input_projection.0.weight'].shape[0]
            
            self.model_b = LSTMAttentionModel(
                input_size=input_size_b,
                hidden_size=hidden_size_b, # Likely 128
                num_layers=2,
                dropout=0.0
            )
            self.model_b.load_state_dict(state_dict_b)
            self.model_b.to(self.device).eval()
            print(f"Loaded Model B (Fold) | Input Size: {input_size_b}")
        except Exception as e:
            print(f"CRITICAL: Failed to load Model B at {path_b}: {e}")
            raise e
            
        # Check compatibility
        if input_size_a != input_size_b:
            print(f"Warning: Models have different input sizes ({input_size_a} vs {input_size_b}). This implies different feature sets were used.")
        
        self.input_size = input_size_a # Assume they match for buffer creation

        # --- Internal State Management ---
        self.current_seq_ix = -1 
        self.state_buffer = [] 

    def predict(self, data_point: DataPoint) -> np.ndarray | None:
        # 1. Manage State Buffer
        if data_point.seq_ix != self.current_seq_ix:
            self.current_seq_ix = data_point.seq_ix
            self.state_buffer = []

        self.state_buffer.append(data_point.state.astype(np.float32))
        
        if len(self.state_buffer) > self.seq_len:
            self.state_buffer.pop(0)

        if not data_point.need_prediction:
            return None

        # 2. Prepare Window
        window = np.array(self.state_buffer, dtype=np.float32)
        if len(window) < self.seq_len:
            pad_len = self.seq_len - len(window)
            pad = np.zeros((pad_len, self.input_size), dtype=np.float32)
            window = np.vstack([pad, window])
        
        x = torch.from_numpy(window).float().unsqueeze(0).to(self.device)

        # 3. Run Inference on Both
        with torch.no_grad():
            # Model A (Stateful Architecture) output shape: (batch, seq, features) -> take last step
            pred_a_seq = self.model_a(x)
            pred_a = pred_a_seq[:, -1, :] # Take last timestep
            
            # Model B (Attention Architecture) output shape: (batch, features)
            pred_b = self.model_b(x)

        # 4. Average Predictions
        avg_pred = (pred_a + pred_b) / 2.0
        
        return avg_pred.cpu().numpy().squeeze(0)

if __name__ == "__main__":
    # Simple local test
    test_file = f"{os.path.dirname(os.path.abspath(__file__))}/../datasets/train.parquet"
    if os.path.exists(test_file):
        try:
            model = PredictionModel()
            from utils import ScorerStepByStep
            scorer = ScorerStepByStep(test_file)
            print("Testing ensemble...")
            results = scorer.score(model)
            print(f"Mean R2: {results['mean_r2']:.6f}")
        except Exception as e:
            print(f"Error during local test: {e}")
