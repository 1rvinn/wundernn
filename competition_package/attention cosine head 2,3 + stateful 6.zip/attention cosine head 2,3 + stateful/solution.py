"""
Solution file for the 2-Model Regime-Switching Ensemble.

Models included:
1. 'LSTMModel': Simple Stateful LSTM (Trained on Top 90%).
   - Checkpoint: 'lstm_stateful_raw_stable_checkpoint.pt'
2. 'LSTMAttentionModel': Attention + Input Projection + Post-Norm (Trained on Fold 4).
   - Checkpoint: 'lstm_attention_proj_fold_4.pt'

Strategy:
- Calculates the volatility (std dev) of the current input window.
- Switches between Model A and Model B based on a defined threshold.
"""

import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
import os

# DataPoint stub for local testing
try:
    from utils import DataPoint
except ImportError:
    from dataclasses import dataclass
    @dataclass
    class DataPoint:
        seq_ix: int
        step_in_seq: int
        need_prediction: bool
        state: np.ndarray

# ==============================================================================
# MODEL A: Simple Stateful LSTM (Corrected for In/Out mismatch)
# ==============================================================================
class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size=128, output_size=None, num_layers=2, dropout=0.1):
        super().__init__()
        if output_size is None:
            output_size = input_size

        self.lstm = nn.LSTM(
            input_size=input_size, 
            hidden_size=hidden_size, 
            num_layers=num_layers, 
            batch_first=True,
            dropout=dropout
        )
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.lstm(x) 
        predictions = self.fc(out)
        return predictions

# ==============================================================================
# MODEL B: Attention + Input Projection (Corrected for In/Out mismatch)
# ==============================================================================
class LSTMAttentionModel(nn.Module):
    def __init__(self, input_size, hidden_size=128, output_size=None, num_layers=2, dropout=0.1):
        super().__init__()
        if output_size is None:
            output_size = input_size

        self.hidden_size = hidden_size
        
        # --- Improvement C: Input Projection ---
        self.input_projection = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.GELU() 
        )
        
        # Encoder
        self.lstm = nn.LSTM(input_size=hidden_size, 
                            hidden_size=hidden_size, 
                            num_layers=num_layers, 
                            batch_first=True, 
                            dropout=dropout,
                            bidirectional=True)
        
        # Attention
        self.attention_fc = nn.Linear(hidden_size * 2, 1)
        
        # Post-Attention Norm
        self.context_norm = nn.LayerNorm(hidden_size * 2)
        
        # Decoder
        self.fc = nn.Linear(hidden_size * 2, output_size)

    def forward(self, x):
        # 1. Apply Input Projection
        x_proj = self.input_projection(x)
        
        # 2. LSTM
        lstm_out, (h_n, c_n) = self.lstm(x_proj)
        
        # 3. Attention
        attention_logits = self.attention_fc(lstm_out)
        attention_weights = F.softmax(attention_logits, dim=1)
        context_vector = torch.sum(attention_weights * lstm_out, dim=1)
        
        # 4. Post-Attention Norm
        context_vector = self.context_norm(context_vector)
        
        # 5. Decode
        return self.fc(context_vector)

# ==============================================================================
# PREDICTION CLASS
# ==============================================================================
class PredictionModel:
    def __init__(self):
        print("Initializing Volatility-Switching Ensemble...")
        script_dir = os.path.dirname(os.path.abspath(__file__))
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        
        # --- Configuration ---
        self.seq_len = 100
        # Tunable threshold for switching models
        self.volatility_threshold = 0.5 
        
        # --- Load Model A (The "Stable/Easy" Expert) ---
        self.model_a = None
        path_a = os.path.join(script_dir, 'lstm_stateful_raw_stable_checkpoint.pt')
        try:
            state_dict_a = torch.load(path_a, map_location=self.device)
            
            # Infer sizes from checkpoint
            input_size_a = state_dict_a['lstm.weight_ih_l0'].shape[1]
            # Infer output size from fc.bias if available, else assume == input
            if 'fc.bias' in state_dict_a:
                output_size_a = state_dict_a['fc.bias'].shape[0]
            else:
                output_size_a = input_size_a
                
            print(f"Model A Dims -> Input: {input_size_a}, Output: {output_size_a}")
            
            self.model_a = LSTMModel(
                input_size=input_size_a, 
                hidden_size=128, 
                output_size=output_size_a,
                num_layers=2, 
                dropout=0.0
            )
            self.model_a.load_state_dict(state_dict_a)
            self.model_a.to(self.device).eval()
            print("Loaded Model A (Stateful/Easy)")
        except Exception as e:
            print(f"CRITICAL: Failed to load Model A at {path_a}: {e}")
            raise e

        # --- Load Model B (The "Volatile/Hard" Expert) ---
        self.model_b = None
        path_b = os.path.join(script_dir, 'lstm_attention_proj_fold_4.pt')
        
        try:
            state_dict_b = torch.load(path_b, map_location=self.device)
            
            # Infer sizes from checkpoint
            input_size_b = state_dict_b['input_projection.0.weight'].shape[1]
            hidden_size_b = state_dict_b['input_projection.0.weight'].shape[0]
            
            if 'fc.bias' in state_dict_b:
                output_size_b = state_dict_b['fc.bias'].shape[0]
            else:
                output_size_b = input_size_b

            print(f"Model B Dims -> Input: {input_size_b}, Output: {output_size_b}")
            
            self.model_b = LSTMAttentionModel(
                input_size=input_size_b,
                hidden_size=hidden_size_b,
                output_size=output_size_b,
                num_layers=2,
                dropout=0.0
            )
            self.model_b.load_state_dict(state_dict_b)
            self.model_b.to(self.device).eval()
            print("Loaded Model B (Attention/Hard)")
        except Exception as e:
            print(f"CRITICAL: Failed to load Model B at {path_b}: {e}")
            raise e
            
        if input_size_a != input_size_b:
            print(f"Warning: Models have different input sizes ({input_size_a} vs {input_size_b}).")
        
        self.input_size = input_size_a 

        # --- Internal State Management ---
        self.current_seq_ix = -1 
        self.state_buffer = [] 

    def predict(self, data_point: DataPoint) -> np.ndarray | None:
        # 1. Manage State Buffer
        if data_point.seq_ix != self.current_seq_ix:
            self.current_seq_ix = data_point.seq_ix
            self.state_buffer = []

        self.state_buffer.append(data_point.state.astype(np.float32))
        
        if len(self.state_buffer) > self.seq_len:
            self.state_buffer.pop(0)

        if not data_point.need_prediction:
            return None

        # 2. Check Volatility (Switching Mechanism)
        current_data = np.array(self.state_buffer, dtype=np.float32)
        # Calculate mean standard deviation across all features
        current_volatility = np.std(current_data, axis=0).mean()
        
        use_model_b = current_volatility >= self.volatility_threshold

        # 3. Prepare Input Window (Pad if necessary)
        window = current_data
        
        # Ensure window width matches expected input size (e.g. 128)
        # If your local 'state' is smaller than the model input, you might need padding or checks here.
        # Assuming for now data_point.state matches input_size.
        
        if len(window) < self.seq_len:
            pad_len = self.seq_len - len(window)
            pad = np.zeros((pad_len, self.input_size), dtype=np.float32)
            window = np.vstack([pad, window])
        
        x = torch.from_numpy(window).float().unsqueeze(0).to(self.device)

        # 4. Inference (Selective)
        prediction = None
        with torch.no_grad():
            if use_model_b:
                # Use Model B (Attention) for High Volatility
                pred_tensor = self.model_b(x)
                prediction = pred_tensor.cpu().numpy().squeeze(0)
            else:
                # Use Model A (Stateful) for Low Volatility/Stable
                pred_seq = self.model_a(x)
                pred_tensor = pred_seq[:, -1, :] 
                prediction = pred_tensor.cpu().numpy().squeeze(0)
        
        return prediction

if __name__ == "__main__":
    # Simple local test
    test_file = f"{os.path.dirname(os.path.abspath(__file__))}/../datasets/train.parquet"
    if os.path.exists(test_file):
        try:
            model = PredictionModel()
            from utils import ScorerStepByStep
            scorer = ScorerStepByStep(test_file)
            print("Testing switching ensemble...")
            results = scorer.score(model)
            print(f"Mean R2: {results['mean_r2']:.6f}")
        except Exception as e:
            print(f"Error during local test: {e}")
